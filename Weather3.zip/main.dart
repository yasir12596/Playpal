import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(MaterialApp(title: "Weather screen3", home: StormyWeather()));
}

class StormyWeather extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var size;
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
          Color.fromARGB(255, 80, 6, 95),
          Color.fromARGB(255, 39, 2, 63),
        ], begin: Alignment.bottomRight, end: Alignment.topLeft)),
        child: Column(children: [
          Container(
            margin: EdgeInsets.only(top: 35),
            width: width * .85,
            height: height * .07,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: width * .12,
                  height: height * 3,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 58, 6, 88),
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Icon(
                    Icons.arrow_back_ios_new,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 55,
            width: 55,
          ),
          Column(
            children: [
              Text("Weather is fine to",
                  style: GoogleFonts.syne(
                    fontSize: 25,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  )),
              Text(" play",
                  style: GoogleFonts.syne(
                    fontSize: 25,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ))
            ],
          ),
          SizedBox(
            height: 55,
            width: 55,
          ),
          Container(
            child: Lottie.network(
                'https://assets5.lottiefiles.com/private_files/lf30_Um0Z9o.json'),
          ),
          SizedBox(
            height: 20,
            width: 55,
          ),
          Text("Clear Sky",
              style: GoogleFonts.syne(
                fontSize: 25,
                color: Colors.white,
                fontWeight: FontWeight.w500,
              )),
          SizedBox(
            height: 100,
            width: 55,
          ),
          Container(
              width: width * .75,
              height: height * .09,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 124, 38, 143),
                  borderRadius: BorderRadius.all(
                    Radius.circular(9),
                  )),
              child: Center(
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                    Text('Proceed to Payment',
                        style: GoogleFonts.syne(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w700)),
                  ])))
        ]),
      ),
    );
  }
}
